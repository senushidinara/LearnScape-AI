# LearnScape AI

## Overview

LearnScape AI is an educational gaming platform that automatically transforms study materials (PDFs, images, text) into immersive, gamified learning experiences. The application uses AI to analyze uploaded content and generate personalized 3D learning worlds with adaptive difficulty, spaced repetition, and engagement mechanics. It's built as a single-page React application that leverages Google's Gemini AI for content generation and world building.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Technology Stack:**
- React 19.2.0 with TypeScript for type-safe component development
- Vite as the build tool and development server
- Tailwind CSS (via CDN) for utility-first styling
- React hooks for state management (useState, useCallback, useEffect)

**Application Flow:**
The app follows a three-state progression managed by a single `App.tsx` component:
1. **Upload State** - User uploads study materials and selects mood
2. **Loading State** - AI processes content and generates world
3. **World State** - User interacts with generated learning content

**State Management Pattern:**
- Local component state using React hooks (no external state management library)
- Props drilling for passing data between parent and child components
- User progress, world history, and player stats maintained in App component state
- Analytics and quest progress tracked through dedicated state objects

**Component Structure:**
- Modular component design with clear separation of concerns
- Screen-level components (UploadScreen, LoadingScreen, WorldScreen)
- Feature-specific components (QuestModal, PlayerStats, ConceptMap, etc.)
- Reusable UI elements (icons, cards, modals)

**Key Architectural Decisions:**
- Client-side only architecture (no backend server)
- All AI processing happens through direct API calls to Google Gemini
- World history stored in memory (resets on page reload)
- PDF parsing handled client-side using PDF.js library

### AI Content Generation

**Google Gemini Integration:**
- Primary AI service for content analysis and world generation
- Structured output using JSON schemas for consistent data shapes
- Generates quiz questions, flashcards, concept maps, and thematic world elements
- Adaptive content generation based on user mood and performance analytics

**Content Processing Pipeline:**
1. User uploads study material (PDF/text)
2. PDF.js extracts text content from PDFs
3. Gemini AI analyzes content to identify key concepts
4. AI generates structured learning world with zones, quests, treasures, and boss battles
5. Content includes spaced repetition metadata and mastery tracking

**Prompt Engineering Strategy:**
- Detailed JSON schemas define expected output structure
- Mood-based adaptation in prompts for personalized difficulty
- Analytics-driven prompts for learning style adaptation
- SVG generation for mathematical visualizations

### Gamification System

**Player Progression:**
- Level-based XP system with exponential growth curve
- XP rewards: 15 for quest success, 5 for failure, 75 for boss victory
- Dynamic XP-to-level calculation: `50 * level² + 50 * level`

**Spaced Repetition System (SRS):**
- Review intervals: [1, 2, 7, 14, 30, 90, 180] days
- Mastery levels track user knowledge retention
- Review scheduling based on forgetting curve principles
- Items marked as "due for review" based on nextReviewDate

**Daily Quest System:**
- Four quest types: review sessions, quest mastery, boss attempts, treasure study
- Progress tracking with completion rewards
- Regenerated when new worlds are created

**Analytics Tracking:**
- Quest attempts and success rates
- Treasure (flashcard) interactions
- Boss battle performance
- Used to calculate learning style preferences and adapt content

### Learning Content Structure

**World Data Model:**
- **Zones**: Themed learning areas with quests, treasures, and interactive challenges
- **Quests**: Multiple-choice questions with explanations and mastery tracking
- **Treasures**: Flashcards for term/definition memorization
- **Boss**: Final challenge with weakness-based questions targeting knowledge gaps
- **Concept Map**: Visual representation of relationships between concepts
- **Interactive Challenges**: SVG-based visualizations (currently math plots)

**Adaptive Difficulty:**
- Mood selection influences initial difficulty calibration
- Analytics-based world regeneration to match learning style
- Performance-driven content adjustment

## Replit Environment Setup

**Development Configuration:**
- Vite dev server configured to run on port 5000 with host 0.0.0.0
- `allowedHosts: true` setting enabled in vite.config.ts for Replit's proxy environment
- Development workflow runs `npm run dev` on port 5000 with webview output

**Deployment Configuration:**
- Deployment target: autoscale (stateless frontend application)
- Build command: `npm run build`
- Run command: `npm run preview -- --host 0.0.0.0 --port 5000`
- Ensures production preview binds to the correct interface and port for Replit deployment

**Environment Variables:**
- `GEMINI_API_KEY` must be set in Replit Secrets for the app to function
- Can be obtained from Google AI Studio at https://aistudio.google.com/apikey
- The app will load without it but cannot generate learning worlds until it's configured

**Recent Changes (November 15, 2025):**
- Migrated project to Replit environment
- Updated Vite configuration from port 3000 to port 5000
- Added allowedHosts configuration for Replit proxy compatibility
- Configured development workflow and deployment settings

## External Dependencies

### Third-Party APIs

**Google Generative AI (@google/genai v1.29.1):**
- Purpose: AI-powered content generation and analysis
- Usage: World generation, question creation, concept extraction
- Configuration: Requires GEMINI_API_KEY environment variable
- Integration: Direct client-side API calls with structured JSON schemas

### Libraries

**PDF.js (pdfjs-dist v4.4.168):**
- Purpose: Client-side PDF parsing and text extraction
- Usage: Extract text content from uploaded PDF study materials
- Configuration: Worker loaded from CDN (pdf.worker.min.mjs)
- Integration: FileReader API with async PDF parsing

**React Ecosystem:**
- react v19.2.0 and react-dom v19.2.0 for UI framework
- @vitejs/plugin-react v5.0.0 for JSX transformation and hot reload

### Build Tools

**Vite (v6.2.0):**
- Development server with hot module replacement
- Environment variable management via loadEnv
- TypeScript compilation and module bundling
- Server configured on port 5000 with CORS enabled

**TypeScript (~5.8.2):**
- Type safety across the application
- ES2022 target with DOM libraries
- Path aliases configured (@/* for root imports)
- React JSX transform enabled

### Content Delivery Networks

**Tailwind CSS:**
- Loaded via CDN script tag in index.html
- No build-time compilation required
- Utility classes applied directly in components

**Import Maps:**
- Google GenAI, React, and PDF.js loaded via import maps
- Uses aistudiocdn.com for AI SDK and React packages
- jsDelivr CDN for PDF.js library

### Environment Configuration

**Required Environment Variables:**
- `GEMINI_API_KEY`: Google Generative AI API key
- Loaded through Vite's loadEnv and exposed via define configuration
- Available as `process.env.API_KEY` and `process.env.GEMINI_API_KEY` in client code

### Potential Future Dependencies

**Database (Not Currently Implemented):**
- Documentation mentions Drizzle ORM and potential PostgreSQL integration
- Would enable persistent storage of user progress and world history
- Current implementation uses in-memory state only

**Additional Services Mentioned in Docs:**
- Wolfram Alpha API for mathematical visualizations (referenced but not implemented in current codebase)
- WebSocket connections for multiplayer features (UI placeholder exists)
- Supabase for backend and authentication (mentioned in documentation but not in code)