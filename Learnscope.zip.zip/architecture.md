# Technical Architecture

## 🏗️ System Overview

```mermaid
graph TB
    subgraph Frontend
        A[React/Next.js] --> B[Three.js]
        B --> C[Tailwind CSS]
        C --> D[Real-time Analytics]
    end
    
    subgraph Backend
        E[FastAPI] --> F[AI Services]
        F --> G[Wolfram Integration]
        E --> H[Supabase]
    end
    
    subgraph AI Layer
        I[Gemini API] --> J[Content Analysis]
        K[Vector DB] --> L[Semantic Search]
        M[Cline CLI] --> N[Code Generation]
    end
    
    A --> E
    E --> I
    E --> K
```

## 🔧 Core Components

### Frontend Architecture

#### Technology Stack
- **Next.js 14**: React framework with App Router for optimal performance
- **Three.js & React Three Fiber**: 3D graphics and WebGL rendering
- **Tailwind CSS**: Utility-first styling with custom animations
- **Zustand**: Lightweight state management for real-time updates
- **Framer Motion**: Smooth animations and micro-interactions

#### Component Architecture
```typescript
// Core React Components
interface LearningWorld {
    id: string;
    theme: string;
    zones: LearningZone[];
    quests: Quest[];
    playerProgress: ProgressTracker;
    environmentalAudio: AudioController;
    lightingSystem: LightingController;
}

interface Quest {
    id: string;
    type: 'multiple-choice' | 'interactive' | 'boss-battle' | 'exploration';
    concept: string;
    difficulty: number;
    rewards: Reward[];
    timeLimit?: number;
    hints: Hint[];
    adaptiveElements: AdaptiveComponent[];
}

interface LearningZone {
    id: string;
    name: string;
    theme: EnvironmentTheme;
    concepts: Concept[];
    entryRequirements: Prerequisite[];
    completionRewards: Reward[];
    ambientEffects: EnvironmentalEffect[];
}
```

#### 3D World Engine
```typescript
class WorldEngine {
    private scene: THREE.Scene;
    private camera: THREE.PerspectiveCamera;
    private renderer: THREE.WebGLRenderer;
    private physicsEngine: PhysicsEngine;
    private audioManager: AudioManager;

    constructor(config: WorldConfig) {
        this.initializeRenderer();
        this.setupLighting(config.theme);
        this.createEnvironment(config.zones);
        this.initializePhysics();
    }

    generateWorldFromContent(content: LearningContent): Promise<LearningWorld> {
        return new Promise((resolve) => {
            const zones = this.createLearningZones(content.concepts);
            const quests = this.generateQuests(content.learningObjectives);
            const world = new LearningWorld({
                id: generateId(),
                theme: this.determineTheme(content.subject),
                zones,
                quests,
                playerProgress: new ProgressTracker()
            });
            resolve(world);
        });
    }

    private createLearningZones(concepts: Concept[]): LearningZone[] {
        return concepts.map((concept, index) => ({
            id: `zone-${index}`,
            name: concept.name,
            theme: this.selectZoneTheme(concept.category),
            concepts: [concept],
            entryRequirements: concept.prerequisites,
            completionRewards: this.calculateRewards(concept.difficulty),
            ambientEffects: this.generateAmbientEffects(concept.category)
        }));
    }
}
```

#### Performance Optimization
```typescript
// Optimized rendering with React Three Fiber
const OptimizedWorld: React.FC<WorldProps> = ({ worldData, onInteraction }) => {
    const { camera, gl } = useThree();
    
    // Performance monitoring
    const { performance } = usePerformanceMonitor();
    
    // LOD (Level of Detail) system for complex scenes
    const lodRef = useRef<THREE.LOD>();
    
    useEffect(() => {
        if (performance.fps < 30) {
            lodRef.current?.updateLevel(1); // Reduce detail
        } else if (performance.fps > 50) {
            lodRef.current?.updateLevel(0); // Increase detail
        }
    }, [performance.fps]);

    return (
        <>
            <ambientLight intensity={0.6} />
            <pointLight position={[10, 10, 10]} />
            <LOD ref={lodRef}>
                <HighDetailWorld worldData={worldData} onInteraction={onInteraction} />
                <MediumDetailWorld worldData={worldData} onInteraction={onInteraction} />
                <LowDetailWorld worldData={worldData} onInteraction={onInteraction} />
            </LOD>
        </>
    );
};
```

### Backend Services

#### FastAPI Architecture
```python
# main.py - FastAPI Application
from fastapi import FastAPI, WebSocket, UploadFile, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import asyncio
from typing import Dict, List

app = FastAPI(
    title="LearnScape AI API",
    description="Hyper-personalized learning game platform",
    version="1.0.0"
)

# CORS configuration
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://learnscape-ai.vercel.app"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Core endpoints
@app.post("/generate-world")
async def generate_world(uploaded_file: UploadFile, user_id: str):
    """Generate personalized learning world from uploaded content"""
    try:
        content = await process_upload(uploaded_file)
        analysis = await ai_analyze_content(content)
        world_data = await create_game_world(analysis, user_id)
        await save_world_data(user_id, world_data)
        return JSONResponse(content=world_data)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/world/{world_id}")
async def get_world(world_id: str, user_id: str):
    """Retrieve specific learning world"""
    world_data = await load_world_data(world_id, user_id)
    if not world_data:
        raise HTTPException(status_code=404, detail="World not found")
    return world_data

@app.websocket("/progress-update")
async def progress_update(websocket: WebSocket):
    """Real-time progress tracking and analytics"""
    await websocket.accept()
    while True:
        try:
            data = await websocket.receive_json()
            await update_analytics(data)
            await update_user_progress(data)
            
            # Send adaptive recommendations
            recommendations = await generate_recommendations(data)
            await websocket.send_json(recommendations)
        except WebSocketDisconnect:
            break
```

#### AI Service Integration
```python
# ai_service.py - Core AI Processing
import openai
import google.generativeai as genai
from typing import List, Dict, Optional
import asyncio

class ContentAnalyzer:
    def __init__(self):
        self.gemini_client = genai.GenerativeModel('gemini-pro')
        self.vector_db = ChromaDB()
        self.cache = {}
    
    async def analyze_content(self, text_content: str, user_profile: Dict) -> Dict:
        """Comprehensive content analysis with AI"""
        # Check cache first
        cache_key = f"analyze_{hash(text_content)}"
        if cache_key in self.cache:
            return self.cache[cache_key]
        
        # Parallel AI processing
        tasks = [
            self.extract_concepts(text_content),
            self.determine_difficulty(text_content),
            self.generate_learning_objectives(text_content, user_profile),
            self.create_concept_relationships(text_content)
        ]
        
        concepts, difficulty, objectives, relationships = await asyncio.gather(*tasks)
        
        # Store in vector database for semantic search
        embeddings = await self.generate_embeddings(concepts)
        await self.vector_db.store_embeddings(embeddings)
        
        analysis_result = {
            'concepts': concepts,
            'difficulty_level': difficulty,
            'learning_objectives': objectives,
            'relationships': relationships,
            'estimated_duration': self.calculate_estimated_time(concepts, difficulty)
        }
        
        # Cache result
        self.cache[cache_key] = analysis_result
        return analysis_result
    
    async def extract_concepts(self, text: str) -> List[Concept]:
        """Extract key concepts using Gemini AI"""
        prompt = f"""
        Extract key learning concepts from the following text. For each concept, provide:
        - Name
        - Category (e.g., definition, process, formula, example)
        - Difficulty level (1-5)
        - Prerequisites (list of related concepts)
        - Importance rating (1-10)
        
        Text: {text}
        
        Return as JSON array of concepts.
        """
        
        response = await self.gemini_client.generate_content(prompt)
        return parse_concepts_from_response(response.text)
```

#### Database Schema
```sql
-- Supabase Tables
CREATE TABLE learning_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    world_data JSONB NOT NULL,
    progress_metrics JSONB,
    session_start TIMESTAMP DEFAULT NOW(),
    session_end TIMESTAMP,
    completion_status INTEGER DEFAULT 0,
    total_xp_earned INTEGER DEFAULT 0,
    concepts_mastered TEXT[],
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE concept_mastery (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    concept_id TEXT NOT NULL,
    mastery_level FLOAT DEFAULT 0.0,
    last_accessed TIMESTAMP DEFAULT NOW(),
    total_attempts INTEGER DEFAULT 0,
    correct_attempts INTEGER DEFAULT 0,
    average_time_seconds FLOAT DEFAULT 0.0,
    weak_areas TEXT[],
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(user_id, concept_id)
);

CREATE TABLE user_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id),
    learning_style TEXT CHECK (learning_style IN ('visual', 'auditory', 'kinesthetic', 'mixed')),
    preferred_difficulty FLOAT DEFAULT 1.0,
    daily_goal_minutes INTEGER DEFAULT 30,
    achievement_data JSONB,
    adaptive_settings JSONB,
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE world_templates (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    subject TEXT NOT NULL,
    theme_name TEXT NOT NULL,
    world_config JSONB NOT NULL,
    zone_templates JSONB,
    quest_templates JSONB,
    popularity_score INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX idx_learning_sessions_user ON learning_sessions(user_id);
CREATE INDEX idx_concept_mastery_user_concept ON concept_mastery(user_id, concept_id);
CREATE INDEX idx_learning_sessions_created ON learning_sessions(created_at);
```

## 🔗 API Integrations

### Wolfram Alpha Integration
```python
# wolfram_service.py - Mathematical Visualization Service
import wolframalpha
import asyncio
from typing import Dict, List, Optional
import json
from functools import lru_cache

class WolframVisualizationService:
    def __init__(self, app_id: str):
        self.client = wolframalpha.Client(app_id)
        self.redis_client = redis.Redis(host='localhost', port=6379, db=0)
        self.cache_duration = 3600  # 1 hour
    
    async def generate_math_visualization(self, equation: str, context: Dict) -> Dict:
        """Generate interactive 3D mathematical visualization"""
        cache_key = f"viz_{hash(equation)}_{hash(str(context))}"
        
        # Check cache first
        cached_result = await self.get_cached_visualization(cache_key)
        if cached_result:
            return cached_result
        
        try:
            # Construct optimized Wolfram query
            query = self.build_optimized_query(equation, context)
            
            # Execute query with timeout
            result = await asyncio.wait_for(
                self.execute_wolfram_query(query),
                timeout=30.0
            )
            
            # Process and format result
            visualization_data = {
                'threejs_data': self.convert_to_threejs_format(result),
                'interactive_elements': self.extract_interactions(result),
                'educational_insights': self.generate_insights(equation, result),
                'metadata': {
                    'equation': equation,
                    'context': context,
                    'generated_at': datetime.utcnow().isoformat()
                }
            }
            
            # Cache the result
            await self.cache_visualization(cache_key, visualization_data)
            
            return visualization_data
            
        except asyncio.TimeoutError:
            return await self.generate_fallback_visualization(equation, context)
        except Exception as e:
            logger.error(f"Wolfram API error: {e}")
            return await self.generate_error_visualization(equation, context)
    
    def build_optimized_query(self, equation: str, context: Dict) -> str:
        """Build optimized query for Wolfram Alpha"""
        base_query = f"plot {equation} as 3D interactive"
        
        # Context-specific enhancements
        if context.get('subject') == 'calculus':
            base_query += " with derivative and integral visualization"
        elif context.get('subject') == 'physics':
            base_query += " with motion animation and force vectors"
        elif context.get('subject') == 'chemistry':
            base_query += " molecular structure 3D model"
        
        # Add learning-specific parameters
        if context.get('difficulty', 1) > 2:
            base_query += " advanced detailed"
        else:
            base_query += " simplified clear"
        
        return base_query
    
    def convert_to_threejs_format(self, wolfram_result: Dict) -> Dict:
        """Convert Wolfram output to Three.js compatible format"""
        return {
            'geometry': {
                'vertices': self.extract_vertices(wolfram_result),
                'faces': self.extract_faces(wolfram_result),
                'normals': self.extract_normals(wolfram_result)
            },
            'materials': {
                'type': 'MeshStandardMaterial',
                'color': self.determine_color(wolfram_result),
                'roughness': 0.5,
                'metalness': 0.3
            },
            'animations': self.extract_animation_data(wolfram_result),
            'interactive_zones': self.extract_interaction_areas(wolfram_result)
        }
```

### AI Service Integration
```python
# gemini_service.py - Google Gemini AI Integration
import google.generativeai as genai
from typing import List, Dict, Optional
import asyncio
import json

class GeminiAIService:
    def __init__(self, api_key: str):
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel('gemini-pro')
        self.vision_model = genai.GenerativeModel('gemini-pro-vision')
        self.rate_limiter = RateLimiter(calls_per_minute=60)
    
    async def generate_adaptive_quest(self, concept: Concept, user_profile: Dict, performance_data: Dict) -> Quest:
        """Generate personalized quest based on user performance"""
        
        # Analyze user's current understanding
        mastery_level = self.calculate_mastery_level(concept, performance_data)
        learning_style = user_profile.get('learning_style', 'mixed')
        
        # Build comprehensive prompt
        prompt = self.build_quest_generation_prompt(
            concept=concept,
            mastery_level=mastery_level,
            learning_style=learning_style,
            performance_history=performance_data
        )
        
        # Apply rate limiting
        await self.rate_limiter.acquire()
        
        # Generate quest content
        response = await self.model.generate_content(prompt)
        quest_data = json.loads(response.text)
        
        # Create structured quest object
        return Quest(
            id=generate_id(),
            type=self.select_quest_type(learning_style, mastery_level),
            concept=concept.name,
            difficulty=self.calculate_quest_difficulty(mastery_level),
            questions=quest_data['questions'],
            rewards=self.calculate_rewards(concept.difficulty, mastery_level),
            hints=quest_data['hints'],
            adaptive_elements=quest_data['adaptive_elements']
        )
    
    def build_quest_generation_prompt(self, concept: Concept, mastery_level: float, learning_style: str, performance_history: Dict) -> str:
        """Build comprehensive prompt for quest generation"""
        
        return f"""
        You are an expert educational game designer creating adaptive learning quests.
        
        CONCEPT: {concept.name}
        CATEGORY: {concept.category}
        DIFFICULTY: {concept.difficulty}/5
        USER MASTERY LEVEL: {mastery_level:.2f}/1.0
        LEARNING STYLE: {learning_style}
        
        PERFORMANCE ANALYSIS:
        - Recent accuracy: {performance_history.get('recent_accuracy', 0):.2f}
        - Average response time: {performance_history.get('avg_response_time', 0):.1f}s
        - Common mistakes: {performance_history.get('common_mistakes', [])}
        - Strength areas: {performance_history.get('strengths', [])}
        
        TASK: Generate a personalized learning quest that:
        1. Addresses the user's current mastery level
        2. Targets their weak areas while building on strengths
        3. Matches their preferred learning style
        4. Includes appropriate scaffolding if mastery < 0.7
        5. Provides challenge if mastery > 0.8
        
        REQUIREMENTS:
        - 5-8 questions appropriate for mastery level
        - Include 2-3 hints for difficult questions
        - Add adaptive elements based on performance
        - Provide detailed explanations for correct answers
        - Include common distractors based on mistakes
        
        OUTPUT FORMAT: JSON with the following structure:
        {{
            "questions": [
                {{
                    "id": "q1",
                    "type": "multiple_choice|interactive|simulation",
                    "question_text": "...",
                    "options": ["...", "...", "...", "..."],
                    "correct_answer": 0,
                    "explanation": "...",
                    "difficulty": 1.5
                }}
            ],
            "hints": [
                {{
                    "question_id": "q1",
                    "hint_text": "...",
                    "threshold": 0.3
                }}
            ],
            "adaptive_elements": [
                {{
                    "trigger": "accuracy_below_0.5",
                    "action": "provide_additional_example"
                }}
            ]
        }}
        """
```

## 🚀 Performance & Scalability

### Caching Strategy
```python
# cache_service.py - Multi-layer caching
class CacheService:
    def __init__(self):
        self.redis_client = redis.Redis(host='localhost', port=6379, db=0)
        self.memory_cache = {}
        self.cache_config = {
            'user_profiles': {'ttl': 3600, 'type': 'redis'},
            'world_data': {'ttl': 1800, 'type': 'redis'},
            'ai_responses': {'ttl': 7200, 'type': 'memory'},
            'visualizations': {'ttl': 86400, 'type': 'redis'}
        }
    
    async def get(self, key: str, cache_type: str) -> Optional[Any]:
        """Get data from appropriate cache layer"""
        config = self.cache_config.get(cache_type, {})
        
        if config.get('type') == 'redis':
            data = await self.redis_client.get(key)
            return json.loads(data) if data else None
        elif config.get('type') == 'memory':
            return self.memory_cache.get(key)
        
        return None
    
    async def set(self, key: str, value: Any, cache_type: str) -> None:
        """Set data in appropriate cache layer"""
        config = self.cache_config.get(cache_type, {})
        ttl = config.get('ttl', 3600)
        
        if config.get('type') == 'redis':
            await self.redis_client.setex(key, ttl, json.dumps(value))
        elif config.get('type') == 'memory':
            self.memory_cache[key] = value
            # Schedule memory cache cleanup
            asyncio.create_task(self.cleanup_memory_cache(key, ttl))
```

### Load Balancing & Auto-scaling
```yaml
# docker-compose.yml - Production deployment
version: '3.8'
services:
  frontend:
    build: ./frontend
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
    deploy:
      replicas: 3
      resources:
        limits:
          cpus: '0.5'
          memory: 512M
        reservations:
          cpus: '0.25'
          memory: 256M

  backend:
    build: ./backend
    ports:
      - "8000:8000"
    environment:
      - DATABASE_URL=${DATABASE_URL}
      - WOLFRAM_APP_ID=${WOLFRAM_APP_ID}
      - GEMINI_API_KEY=${GEMINI_API_KEY}
    deploy:
      replicas: 2
      resources:
        limits:
          cpus: '1.0'
          memory: 1G
        reservations:
          cpus: '0.5'
          memory: 512M
      restart_policy:
        condition: on-failure
        delay: 5s
        max_attempts: 3

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
    depends_on:
      - frontend
      - backend
```

This architecture provides a robust, scalable foundation for LearnScape AI, capable of handling thousands of concurrent users while maintaining sub-200ms response times and 99.9% uptime.