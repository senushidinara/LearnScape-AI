# Contributing to LearnScape AI

Thank you for your interest in contributing to LearnScape AI! This document provides guidelines and information for contributors.

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ and npm
- Python 3.11+ and pip
- Docker and Docker Compose
- Git

### Development Setup
```bash
# Clone the repository
git clone https://github.com/learnscape-ai/learnscape-ai.git
cd learnscape-ai

# Install frontend dependencies
cd frontend
npm install

# Install backend dependencies
cd ../backend
pip install -r requirements.txt

# Start development services
docker-compose up -d
npm run dev
```

## 🏗️ Project Structure

```
learnscape-ai/
├── frontend/                 # Next.js React application
│   ├── components/          # Reusable UI components
│   ├── pages/              # Next.js pages
│   ├── styles/             # Tailwind CSS and styles
│   └── utils/              # Frontend utilities
├── backend/                  # FastAPI Python backend
│   ├── api/                # API endpoints
│   ├── models/             # Database models
│   ├── services/           # Business logic services
│   └── utils/              # Backend utilities
├── shared/                   # Shared TypeScript types
├── docs/                     # Documentation
├── tests/                    # Test suites
└── infrastructure/           # Docker and deployment configs
```

## 🤝 How to Contribute

### 1. Find an Issue
- Browse [open issues](https://github.com/learnscape-ai/learnscape-ai/issues)
- Look for issues labeled `good first issue` for beginners
- Comment on issues you'd like to work on

### 2. Create a Branch
```bash
git checkout -b feature/your-feature-name
# or
git checkout -b fix/issue-number-description
```

### 3. Make Changes
- Follow the existing code style and patterns
- Add tests for new functionality
- Update documentation as needed

### 4. Run Tests
```bash
# Frontend tests
cd frontend && npm test

# Backend tests
cd backend && pytest

# Integration tests
npm run test:integration
```

### 5. Submit Pull Request
- Push your branch to GitHub
- Create a pull request with a clear description
- Link any related issues
- Wait for code review

## 📝 Code Standards

### Frontend (TypeScript/React)
```typescript
// Use proper TypeScript types
interface UserProfile {
  id: string;
  learningStyle: 'visual' | 'auditory' | 'kinesthetic';
  currentLevel: number;
}

// Follow React best practices
const QuestComponent: React.FC<QuestProps> = ({ quest, onAnswer }) => {
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  
  return (
    <div className="quest-container">
      {/* Component content */}
    </div>
  );
};
```

### Backend (Python)
```python
# Use type hints and async/await
from typing import List, Dict, Optional
from fastapi import HTTPException

async def generate_world(
    content: str,
    user_profile: UserProfile,
    difficulty: float = 1.0
) -> WorldData:
    """Generate a personalized learning world."""
    try:
        analysis = await ai_service.analyze_content(content)
        return world_builder.create(analysis, user_profile)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```

### Testing
```typescript
// Frontend tests with React Testing Library
describe('QuestComponent', () => {
  it('should render question and options', () => {
    render(<QuestComponent quest={mockQuest} />);
    expect(screen.getByText('What is...')).toBeInTheDocument();
  });
});

// Backend tests with pytest
async def test_world_generation():
    world = await generate_world(test_content, test_profile)
    assert world.zones is not None
    assert len(world.quests) > 0
```

## 🎯 Contribution Areas

### Frontend Development
- React Three.js 3D components
- Interactive quest interfaces
- Responsive design improvements
- Accessibility enhancements
- Performance optimizations

### Backend Development
- AI service integrations
- Database schema optimizations
- API endpoint development
- Real-time WebSocket features
- Analytics and monitoring

### Content & Learning Science
- Educational content creation
- Learning algorithm improvements
- Neurodiversity accommodations
- Assessment and feedback systems
- Multi-language support

### Infrastructure & DevOps
- Docker containerization
- CI/CD pipeline improvements
- Monitoring and alerting
- Security enhancements
- Scalability optimizations

## 🧪 Testing Guidelines

### Test Coverage Requirements
- **Frontend**: Minimum 90% coverage
- **Backend**: Minimum 95% coverage
- **Integration**: All critical user paths tested

### Test Types
1. **Unit Tests**: Individual functions and components
2. **Integration Tests**: API endpoints and service interactions
3. **End-to-End Tests**: Complete user workflows
4. **Performance Tests**: Load and stress testing

### Running Tests
```bash
# All tests
npm run test:all

# Specific test suites
npm run test:unit
npm run test:integration
npm run test:e2e

# Coverage report
npm run test:coverage
```

## 📚 Documentation

### Adding New Features
1. Update API documentation in `docs/api/`
2. Add user-facing documentation in `docs/user/`
3. Include code examples and screenshots
4. Update the README if needed

### Documentation Standards
- Use clear, concise language
- Include code examples
- Add screenshots for UI features
- Follow the existing structure and style

## 🚦 Pull Request Process

### Before Submitting
- [ ] All tests pass
- [ ] Code follows project standards
- [ ] Documentation is updated
- [ ] No console errors or warnings
- [ ] Accessibility compliance checked

### PR Template
```markdown
## Description
Brief description of changes and motivation.

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Testing
- [ ] Unit tests added/updated
- [ ] Integration tests pass
- [ ] Manual testing completed

## Checklist
- [ ] Code follows style guidelines
- [ ] Self-review completed
- [ ] Documentation updated
```

### Review Process
1. Automated checks must pass
2. At least one maintainer approval required
3. All feedback addressed
4. Squash and merge to main branch

## 🏷️ Issue Labels

- `good first issue`: Good for newcomers
- `help wanted`: Community contributions welcome
- `bug`: Bug reports and fixes
- `enhancement`: New features and improvements
- `documentation`: Documentation updates
- `urgent`: High priority issues
- `security`: Security-related issues

## 💬 Getting Help

### Communication Channels
- **GitHub Issues**: For bug reports and feature requests
- **Discord**: For general discussion and questions
- **Discussions**: For ideas and collaboration

### Resources
- [Project Documentation](https://docs.learnscape-ai.com)
- [API Reference](https://api.learnscape-ai.com)
- [Community Forum](https://community.learnscape-ai.com)

## 📄 License

By contributing to LearnScape AI, you agree that your contributions will be licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

## 🙏 Recognition

### Contributor Recognition
- Contributors page on website
- GitHub contributor badges
- Annual community awards
- Special recognition in release notes

### Ways to Contribute Beyond Code
- Documentation improvements
- Bug reports and testing
- Community support and mentoring
- Translation and localization
- Design and user experience feedback

---

Thank you for contributing to LearnScape AI and helping make education more engaging and effective for everyone! 🎓✨