# Assets Directory

This directory contains visual assets for the LearnScape AI GitBook documentation.

## Contents

### Images
- `banner.png` - Main project banner for the README
- `architecture-diagram.png` - System architecture visualization
- `game-screenshots/` - Screenshots from the actual application
  - `world-generation.png` - World creation interface
  - `quest-interface.png` - Active quest gameplay
  - `boss-battle.png` - Boss battle engagement
  - `progress-dashboard.png` - Analytics and progress tracking

### Cline CLI Integration
- `cline-prompts/` - Screenshots demonstrating Cline CLI usage
  - `world-engine-generation.png` - Generating 3D world components
  - `ai-integration-setup.png` - AI service integration
  - `adaptive-algorithm.png` - Learning algorithm implementation

### Demo Content
- `demo-frames/` - Key frames from the demo video
  - `upload-to-world.gif` - Content upload to world generation
  - `learning-journey.gif` - Complete learning session flow
  - `mathematical-visualization.gif` - Wolfram Alpha integration showcase

## Usage

All assets should be referenced using relative paths from the GitBook root:

```markdown
![Banner](assets/banner.png)
```

## Asset Guidelines

- **Format**: Use PNG for screenshots, GIF for animations
- **Size**: Optimize for web loading (max 2MB per image)
- **Resolution**: Minimum 1920x1080 for screenshots
- **Naming**: Use kebab-case with descriptive names
- **Alt Text**: Always include descriptive alt text for accessibility

## License

All assets are created specifically for LearnScape AI and are included under the project MIT license.